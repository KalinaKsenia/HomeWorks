package ru.web.notes.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import ru.web.notes.deo.WebNoteDAO;
import ru.web.notes.models.WebNote;

@Controller
@RequestMapping("/notes")
public class NotesController {
    private final WebNoteDAO dao;

    @Autowired
    public NotesController(WebNoteDAO dao) {
        this.dao = dao;
    }

    @GetMapping()
    public String index(Model model) {
        model.addAttribute("notes", dao.index());
        return "notes/index";
    }

    @GetMapping("/{id}")
    public String show(@PathVariable("id") int id, Model model) {
        System.out.println("==> SHOW");
        model.addAttribute("note", dao.show(id));
        return "notes/show";
    }

    @GetMapping("/help")
    public String getHelp() {
        System.out.println("Help!!!");
        return "notes/help";
    }

    @GetMapping("/new")
    public String newNote(Model model) {
        System.out.println("==> NEW");
        model.addAttribute("webNote", new WebNote());
        return "notes/new";
    }

    @GetMapping("{id}/edit")
    public String edit(Model model, @PathVariable("id") int id) {
        System.out.println("==> EDIT");
        model.addAttribute("webNote", dao.show(id));
        return "notes/edit";
    }

    @PatchMapping("/{id}")
    public String update(@ModelAttribute("webNote") WebNote webNote, @PathVariable("id") int id) {
        System.out.println("==> UPDATE");
        dao.update(id, webNote);
        return "redirect:/notes";
    }
}

