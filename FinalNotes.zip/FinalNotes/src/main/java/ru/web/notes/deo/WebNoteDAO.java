package ru.web.notes.deo;

import org.springframework.stereotype.Component;
import ru.web.notes.models.WebNote;

import java.util.ArrayList;
import java.util.List;

@Component
public class WebNoteDAO {
    private static int NOTES_COUNT;
    private List<WebNote> notes;
    public WebNoteDAO() {
        notes = new ArrayList<WebNote>();
        notes.add(new WebNote(++NOTES_COUNT, "Masha"));
        notes.add(new WebNote(++NOTES_COUNT, "Gleb"));
        notes.add(new WebNote(++NOTES_COUNT, "Kail"));
        notes.add(new WebNote(++NOTES_COUNT, "Sten"));
        notes.add(new WebNote(++NOTES_COUNT, "Arik"));
    }

    public List<WebNote> index() {
        return notes;
    }
    public WebNote show(int id) {
        System.out.println("WebNote show() id = "+id);
        return notes.stream().filter(n->n.getId()==id).findAny().orElse(null);
    }
    public void save(WebNote note) {
        note.setId(++NOTES_COUNT);
        notes.add(note);
    }
    public void update(int id, WebNote updateNote) {
        System.out.println("update "+ id);
        WebNote toUpdateNote = show(id);
        toUpdateNote.setNote(updateNote.getNote());
    }
    public void delete(int id) {
        notes.removeIf(n->n.getId()==id);
    }
}

